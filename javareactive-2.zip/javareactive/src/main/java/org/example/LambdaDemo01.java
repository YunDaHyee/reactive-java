package org.example;

public class LambdaDemo01 {
    public static void main(String[] args) {
        TestInterface result = (a, b) -> a+b;
    }
    public static void useLambdaDemo(TestInterface ti, int a, int b){
        //System.out.println( ti(a,b) );
    }

    /*private static boolean ti(int a, int b) {
    }*/
}

@FunctionalInterface
    interface TestInterface{
        int addTwoNumbers(int a, int b);
}

class MyClass implements TestInterface{
    @Override // 추상메서드를 구현해야함.
    public int addTwoNumbers(int a, int b) {
        return a+b;
    }
}