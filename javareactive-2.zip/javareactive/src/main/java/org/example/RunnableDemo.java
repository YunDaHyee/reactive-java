package org.example;

public class RunnableDemo {
    public static void main(String[] args) {
       /* Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                for( int i=0;i<100;i++ ){
                    System.out.println( "Another thread : " + i );
                }
            }
        });*/

        // 위의 코드를 람다식으로 아래와 같이 표현
        // 람다식에도 바디에 여러라인에 걸친 코드가 있으면 중괄화 생략 불가
        Thread t = new Thread( () -> {
            for( int i=0;i<100;i++ ){
                System.out.println( "Another thread : " + i );
            }
        });

        t.start();

        for( int i=0;i<100;i++ ){
            System.out.println( "main thread : " + i );
        }
    }
}
