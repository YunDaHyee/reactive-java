package org.example.rxjava;

import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.core.Observer;
import io.reactivex.rxjava3.disposables.Disposable;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class RxJavaDemo02 {
    public static void main(String[] args) {
        // Reactive Programming 방식 2 - fromIterable 이용
        System.out.println( "Reactive Programming 방식 2" );
        System.out.println();
        List<String> colors2 = Arrays.asList("red", "blue", "white", "orange");
        Observable<String> stringObservable = Observable.fromIterable(colors2); // 실제 데이터를 가지고 있는 공급자. ColdObservable.. 데이터를 언제 쏘냐면 Obserber가 subscribe 하는 순간 쏨.
        // ColdObservable - Subscribe 하는 순간 움직이는 애(일반적인 경우)
        // HotObservable - 지혼자 emit하는 것.
        stringObservable.subscribe( new MyObserver() ); // stringObservable가 던지는 것을 Observer인 MyObserver가 받아먹을 수 있게 됨. subscribe 했으니까 emit이 시작됨. 이거 이후에 자동으로 onNext()가 데이터 개수만큼 실행됨.


        /*
            항상 MyObserver 처럼 만들어 쓸 순 없으니까 OnNext만 바로 필요할 땐 onNext 인자만 잇는 거 쓰면 돼.
             긍까 콜백이 필요할 떄마다 다르게 사용 가능함
        */
        // OnNext()만 콜백하는 Observable
        System.out.println( "OnNext()만 콜백하는 Observable" );
        stringObservable.subscribe( data -> System.out.println(data) );

        // OnNext(),onError() 콜백하는 Observable
        System.out.println( "OnNext(),onError() 콜백하는 Observable" );
        stringObservable.subscribe(
                data -> System.out.println(data),
                error -> System.out.println("에러 발생")
        );
        // OnNext(),onError(),onComplete() 콜백하는 Observable
        System.out.println( "OnNext(),onError(),onComplete() 콜백하는 Observable" );
        Disposable disposable = null;
        Disposable finalDisposable = disposable;
        disposable = stringObservable.subscribe(
                data -> {
                    System.out.println(data + " FROM OBSERVABLE");
                    if( data.equals("end") ){
                        finalDisposable.dispose();
                    }
                }, // onNext(). DT 처리하는 부분
                error -> System.out.println("에러 발생 " + error), // 파라미터만 있고 뱉기만 하는 건 Consumer
                () -> System.out.println("EMIT 종료") // 파라미터랑 리턴값 없음. 이런 건 Runnable이라 함.
        );
    }
}

// Observer : Observable을 사용하는 애.
class MyObserver implements Observer<String>{
    private Disposable d;
    // subscribe 하는 순간 이 함수가 콜백됨.
    @Override
    public void onSubscribe(@NonNull Disposable d) { // 옵저버블이라서 Disposable인데 Flowebr이면 Subscription을 줌.
        this.d = d;
        System.out.println( "===== 구독 시작됨 =====" );
    }

    @Override
    public void onNext(@NonNull String s) {
        // 강제로 구독 종료시키기 위함
        if( s.equals("end") ){
            d.dispose();
        }
        System.out.println( s + " FROM OBSERVABLE");
    }

    @Override
    public void onError(@NonNull Throwable e) { // 에러나면 얘가 콜백됨

    }

    @Override
    public void onComplete() {
        System.out.println( "===== 데이터 EMIT 완 =====" );
    }
}