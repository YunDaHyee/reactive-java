package org.example;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class SortDemo {
    public static void main(String[] args) {
        List<String> colors = Arrays.asList("red", "black", "tan", "orange", "white", "yellow"); // 양수면 리턴하고 음수면 그대로

        // 1. 원본이 정렬되는 호출 형태.
        // colors.sort( new MyComparator() );

        // 2. java 1.5 익명 이너 클래스 형태.
        /*
        colors.sort(new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return o1.length()-o2.length();
            }
        });
        */

        // 3. 람다식 형태
        colors.sort( (o1, o2) -> o1.length() - o2.length() ); // 회색으로 되어있다는 건 리팩토링 여지가 남아있다는 것. 이런 식으로 되어있는 건 메서드 레퍼런스 형태, 즉, 람다의 컴팩트 표현식으로 표현 가능하다!

        // 4. 람다식 형태 - 메서드 레퍼런스
        colors.sort( Comparator.comparingInt(String::length) ); // 람다의 컴팩트 표현식


        System.out.println( colors );

        // Comparator는 함수형인터페이스라서 람다식으로 표현 가능함
    }
}

class MyComparator implements Comparator<String> {

    // 오버라이딩 하려는 메서드 목록 뜰 때, 동그라미가 뚫려있는 건 추상메서드고 동그라미가 꽉 차있는건 default method
    @Override
    public int compare(String o1, String o2) {
        return o1.length()-o2.length(); // 글자 순서대로 정렬이 됨.
    }
}