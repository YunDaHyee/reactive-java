package com.example.webfluxDemo.controller;

import com.example.webfluxDemo.model.Article;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.List;

@RestController
public class ReactiveGramController {
    // 전체 글 보기 : 글번호, 제목, 내용, 좋아요
    @GetMapping("/articles")
    //public List<Article> article(){ // NOT reactive
    public Flux<Article> article(){
        List<Article> articles = Arrays.asList(
                new Article( 1, "aa", "abcdefg", 0),
                new Article( 2, "bb", "abcdefg", 3),
                new Article( 3, "cc", "abcdefg", 12),
                new Article( 4, "dd", "abcdefg", 34),
                new Article( 5, "ee", "abcdefg", 35)
        );
        // return articles; // 이렇게 나갔을 때, Json으로 바꿔주는 것도 Spring이 해줌.
        return Flux
                .fromIterable(articles)
                .filter( d->d.getLikes()>=10 );
    }

    // 글 상세보기
    // 글 하나가 무조건 보여진다는 전제라서 Mono 사용
    // 데이터 사이즈가 작으면 속도가 오히려 느리대. 예전방식이 낫다고 함. 근데 .. 머 나중되면 이거 다 쓰겠지
    // Reactive 방식 아니면 Article.
    @GetMapping("/articles/{id}")
    public Mono<Article> detail(@PathVariable long id){
        return Mono.just( new Article(id, "aaa", "bb",10) );
    }
}
