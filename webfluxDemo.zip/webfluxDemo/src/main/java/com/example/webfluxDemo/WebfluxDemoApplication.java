package com.example.webfluxDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebfluxDemoApplication {
	// springboot에 서버가 내장되어잇어서 실행만 하면 됨. webFlux를 쓰면 서블릿 스택 방식이 아니라서 톰캣 서버가 아니고 reactive한 방식인 netty 서버가 실행됨.
	public static void main(String[] args) {
		SpringApplication.run(WebfluxDemoApplication.class, args);
	}

}
