package com.example.webfluxDemo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController // RestAPI 서비스를 하는 컨트롤러
public class HomeController {

    @GetMapping("/") // URL에 따른 라우팅..
    //public String hello() { // 생짜로 던지는 게 아니고
    public Mono<String> hello() { // Mono로 wrapping해서 준다
        return Mono.just("Hello world !"); // just만 했어도 최종적으로 나가기 전에 Spring이 리턴되는 Mono을 잡고 subscribe해서 내용을 던져줌. 쓰레드 뿌려주는 거보다 내부적으로 이게 더 빨라서 효율적. 이후에는 Reactor의 연산자를 통해서 가공할 수 있음..
    }

    @GetMapping("/about")
    //public String about(){
    public Mono<String> about(){
        return Mono.just("copyright 2023 by kitri");
    }

}
