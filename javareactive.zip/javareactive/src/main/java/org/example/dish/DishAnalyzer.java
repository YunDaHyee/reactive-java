package org.example.dish;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class DishAnalyzer {
    public static void main(String[] args) {
        List<Dish> dishes = Arrays.asList(
                new Dish("pork" ,false, 800, "MEAT"),
                new Dish("beef" ,false, 900, "MEAT"),
                new Dish("rice" ,true, 600, "OTHER"),
                new Dish("spagetti" ,true, 750, "NOODLE"),
                new Dish("banana" ,true, 500, "FRUIT"),
                new Dish("apple" ,true, 800, "FRUIT"),
                new Dish("melon" ,true, 450, "FRUIT"),
                new Dish("salmon" ,true, 400, "FISH"),
                new Dish("prawn" ,true, 300, "FISH")
        );

        // 700 칼로리 미만의 요리를 검색해서 상위 3가지 요리의 이름 3개를 칼로리 낮은 순으로 출력
        List<String> dishResult = dishes.stream() // 이 라인에서는 Stream<Dish> 이렇게 반환이 됨. 스트림으로 처리 시, 첫 번째는 데이터 소스를 스트림으로 변환.
                .filter( dish -> dish.getCalories()<700 ) // Stream<Dish>을 반환. Predicate을 받게 함.
                //.sorted( (a, b) -> a.getCalories()-b.getCalories() ) // Stream<Dish>을 반환. 파라미터 없는 건 오름차순으로 정렬함. comparaotr은 일종의 bicomparator임. 양수를 반환하면 그대로, 음수를 반환하면 순서를 바꾸는 것.
                .sorted(Comparator.comparingInt(Dish::getCalories)) // 리팩토링 한 것
                //.map( dish -> dish.getName() ) // 람다식 써놓고 머 리팩토링 박스 뜨면 클릭하면 메서드레퍼런스로 바꿔줌..
                .map(Dish::getName) // 파라미터로 Stream<Dish>로 들어올텐데 getName을 찾는 거라서 map(매핑을) 써서 Stream<String>을 딱 반환해줌. 얘의 인터페이스가 Function의 구현체라서 A가 드가서 B가 나오는 형태.
                .collect( Collectors.toList() ); // Stream 타입은 사용할 수가 없어. 쓰려면 현찰(소위말하는)로 변환해서 써야하기 땜에(가공해서 써야하기 위해서) 반환받기위해 collect를 해줌. 그럼 List<STring>을 반환함.
        // 데이터반환하는 건 촌스러운 형태인데 이건 이론적인 거긴 함..
        // 리턴하는 타입을 알려주는 건 Introduce LocalVariable 클릭하면 돼.

        // 데이터처리는 순서대로 이뤄지는데 뭐가 더 먼저 되어야 하는지는 사람이 잘 판단해서 해야함.
        // 중간 연산(intermidate operate)은 가공하는 과정이라서 N번 올 수 있고 최종연산(terminal operator) 은 1번만 올 수 있음(최종적으로 받는 결과물)
        // 근데 결국은 이게 다 SQL에서 지원하는 거라서 요즘엔 저 위에서 한 것처럼 안하구 sqlmapper로 씌워서 데이터 처리하는 추세임. 하둡..스파크...클라우드 빅데이터 처리하는 기술들이 sql을 다 지원함..
        // 결국 이 형태는 많이는 안쓰임..
        // 근ㄷ ㅔ rx는 개발자영역임.. 리액티브

        System.out.println( dishResult );
    }
}
