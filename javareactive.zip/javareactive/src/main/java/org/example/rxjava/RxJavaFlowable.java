package org.example.rxjava;

import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Flowable;
import io.reactivex.rxjava3.core.FlowableOnSubscribe;
import io.reactivex.rxjava3.core.FlowableSubscriber;
import io.reactivex.rxjava3.core.Observable;
import org.reactivestreams.Subscription;

public class RxJavaFlowable {
    public static void main(String[] args) {
        Observable.just( "red", "blue", "orange" )
                .filter( d->d.length()>4 )
                .subscribe( d-> System.out.println(d) ); // Observer를 받음

        Flowable.just( "red", "blue", "orange" )
                .filter( d -> d.length()>4 )
                .subscribe( new MySubscriber() );

        /*
            두개가 똑같은데 차이점은 onSubscribe()의 전달할 때의 인자
                - Observer - Disposable
                - FlowableSubscriber - Subscription
                    - Subscription의 메소드에 cancee 배합 기능이 있음
                    (데이터가 emit 되는데의 양(배합)을 조절하는 것)
                    - 데이터 양을 조절해야할 정도로 많을 때 사용함.
         */
    }
}

class MySubscriber implements FlowableSubscriber {
    private Subscription s;
    @Override
    public void onSubscribe(@NonNull Subscription s) { // 구독 시작할 때의 콜백함수.
        this.s = s;
        s.request(3); // 데이터 3개만 보내줘..!
    }

    @Override
    public void onNext(Object o) {
        s.request(3); // 보낼 떄 3개씩 보내달라고 정의해놓는 것.
    }

    @Override
    public void onError(Throwable throwable) {

    }

    @Override
    public void onComplete() {

    }
}