package org.example.rxjava;

import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.observables.ConnectableObservable;

public class HotObservableDemo {
    public static void main(String[] args) {
        ConnectableObservable<String> source = Observable.just("Alpha", "Beta", "Gamma").publish(); // HotObservable을 만들어줌
        //Set up observer 1
        source.subscribe(s -> System.out.println("Observer 1: " + s)); // 이렇게 해도 바로 emit이 되지 않음.
        //Setup observer 2
        source.map(s -> s.length())
                .subscribe(i -> System.out.println("Observer 2: " + i)); // 이렇게 해도 바로 emit이 되지 않음.
        //Fire!
        source.connect(); // 여기서 emit(데이터 전달)이 수행이 됨.
    }

}
