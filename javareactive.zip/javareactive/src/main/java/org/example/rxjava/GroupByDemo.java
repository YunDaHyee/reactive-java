package org.example.rxjava;

import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.observables.GroupedObservable;

public class GroupByDemo {
    public static void main(String[] args) {
        Observable<String> source = Observable.just("Alpha", "Beta", "Gamma", "Delta","Epsilon");
        Observable<GroupedObservable<Integer, String>> byLengths = source.groupBy(s -> s.length());

        // ex 1) 단순 리스트로 만든 것 출력
        System.out.println("단순 리스트로 만든 것 출력");
        byLengths
                .flatMapSingle(grp -> grp.toList())
                .subscribe(System.out::println);

        // ex 2) 집계까지
        System.out.println();
        System.out.println("집계까지");
        byLengths.flatMapSingle(grp ->
                grp.reduce("", (x, y) -> x.equals("") ? y : x + ", " + y)
                        .map(s -> grp.getKey() + ": " + s)
        ).subscribe(System.out::println);
    }
}
