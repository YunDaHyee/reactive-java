package org.example.rxjava;

import io.reactivex.rxjava3.core.Observable;

import java.util.concurrent.TimeUnit;

public class RxJavaDemo04 {
    public static void main(String[] args) throws InterruptedException {
        Observable
                .create( emitter -> { // create를 통해 데이터 수동으로 쓰는 법을 작성. 많이 안 쓰긴함.
                    for( int i=0;i<=100;i++ ){
                        emitter.onNext( i );
                    }
                    //emitter.onComplete(); // 이걸 안쏘면 종료가 안돼. 여기선 main이 저까지니까 걍 프로그램이 정상 종료되는거지만 유지된다는 가정이 잇으면 계약이 안끝난 상태임.
                }).subscribe(System.out::println);

        Observable
                .range( 1, 5 ) // int형 숫자를 바로 만들어서 emmit해줌
                .subscribe( d -> System.out.println(d) );

        //time interval로 인ㄹ련의숫자를 끝나는 게 없음.
        /*
        Observable
                .interval( 500, TimeUnit.MICROSECONDS ) // Observer이 0.5초마다 마이크로세컨드가 하나식 반환되는 것. 안끝남.
                .subscribe( d -> System.out.println(d) );

        Thread.sleep( 10000 );
        */
        Observable.just(5, 3, 7)
                .reduce("", (total, i) -> total + (total.equals("") ? "" : ",") + i)
                .subscribe(s -> System.out.println("Received: " + s));

        Observable.just(5, 2, 4, 0, 3)
                .map(i -> 10 / i)
                .onErrorReturnItem(-1)
                .subscribe(i -> System.out.println("RECEIVED: " + i),
                        e -> System.out.println("RECEIVED ERROR!!!!!!!!!!!!!!!!! : " + e)); // 얘는 실행 안됨.onErrorReturnItem 있어서

        Observable.just(5, 2, 4, 0, 3)
                .map(i -> {
                    try {
                        return 10 / i;
                    } catch (ArithmeticException e) {
                        return -1;
                    }
                })
                .subscribe(i -> System.out.println("RECEIVED: " + i),
                        e -> System.out.println("RECEIVED ERROR~~~~~~~: " + e));

        System.out.println();
        Observable.just(5, 2, 4, 0, 3)
                .map(i -> 10 / i)
                .retry(2)
                .subscribe(i -> System.out.println("RECEIVED: " + i),
                        e -> System.out.println("RECEIVED ERROR!!!!!!!!! " + e));

        Observable<Integer> just = Observable.just(5, 2, 4, 0, 3);
        just
                .doOnNext( d-> System.out.println("log : " + d ) )
                .doOnSubscribe( d2 -> System.out.println("구독 시작") )
                .timestamp() // emit하는 시간.. 현지시간, 단위, 값.. Timed 클래스로 매핑돼서 값이 출력되게하기 위함.
                .subscribe( d -> System.out.println(d) );
        just.subscribe( d -> System.out.println(d) );
        //스트림은 한번 사용하고나면 끝인데 Observable은 재사용 가능함. 그래서 한버 Subscriptoin하고 나서 또 할 수 잇음. 특징..! 자바는 한번 사용하면 끝임
    }
}

