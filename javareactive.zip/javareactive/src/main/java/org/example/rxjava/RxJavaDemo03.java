package org.example.rxjava;

import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.core.Observer;
import io.reactivex.rxjava3.disposables.Disposable;

import java.util.Arrays;
import java.util.List;

public class RxJavaDemo03 {
    public static void main(String[] args) {
        // stream 보다는 RxJava가 깔끔함.
        /* Reactive Programming 방식 1 - just */
        
        // 기본 프로세스
        // 1. Observable 생성
        System.out.println( "Reactive Programming 방식 1" );
        Observable<String> colors
                = Observable.just("red", "blue", "white", "orange"); // 공급자
        // 2. 연산자 - 생략

        // 3. Observer로 옵저버블을 사용
        // subscribe 함수로 사용 가능
        colors.subscribe( color -> System.out.println(color) ); // 인자가 Consumer니까 먹어버리는 거라서 리턴이 없는 것.

        // ==
        System.out.println();
        // 코드를 한번에 처리하는 식 - 보통 이렇게 많이 함.
        // 함수형 프로그래밍에서는 반환을 해주는 걸 안좋아하고 바로 사용해버리는 패턴을 좋아함.
        Observable
                .just("red", "blue", "white", "orange") // DT 생성
                .filter( d -> d.length()>=4 )           // 연산자 1
                .map(String::toUpperCase)               // 연산자 2
                .subscribe(System.out::println);        // 사용
    }
}

