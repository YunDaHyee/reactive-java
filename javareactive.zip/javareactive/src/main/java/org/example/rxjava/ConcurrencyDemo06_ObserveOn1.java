package org.example.rxjava;

import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.schedulers.Schedulers;

import java.util.concurrent.TimeUnit;

public class ConcurrencyDemo06_ObserveOn1 {
    public static void main(String[] args) {
        //Starts on IO Scheduler
        Observable
                .just("WHISKEY/27653/TANGO", "6555/BRAVO","232352/5675675/FOXTROT")
                .subscribeOn(Schedulers.io()) // 별도의 쓰레드에서 돌아라. 그래서 emit이 여기서 시작됨. 데이터 쏘는 놈
                .flatMap(s -> Observable.fromArray(s.split("/"))) // flatMap. 별도의 쓰레드에서 돔. 별도의 Observable로 만드는 작업이 별도의 쓰레드에서 도는 것임. 병렬처리가 됨.
                .observeOn(Schedulers.computation())   //Switches to Computation Scheduler. 쓰레드가 바뀜.
                .filter(s -> s.matches("[0-9]+"))
                .map(Integer::valueOf)
                .reduce((total, next) -> total + next)
                .subscribe(i ->
                        System.out.println("Received " + i + " on thread " + Thread.currentThread().getName())
                ) // 데이터 실행하는 놈.
        // 각각 다른 쓰레드에서 실행된다.
        ;
        sleep(1000);
    }

    private static void sleep(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
