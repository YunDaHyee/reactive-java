package org.example.rxjava;

import io.reactivex.rxjava3.core.Observable;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class RxJavaDemo01 {
    public static void main(String[] args) {
        // Reactive Programming 방식 1 - just
        System.out.println( "Reactive Programming 방식 1" );
        Observable<String> colors
                = Observable.just("red", "blue", "white", "orange"); // 공급자
        colors.subscribe( color -> System.out.println(color) ); // 인자가 Consumer니까 먹어버리는 거라서 리턴이 없는 것.

        // Reactive Programming 방식 2 - fromIterable 이용
        System.out.println();
        System.out.println( "Reactive Programming 방식 2" );
        List<String> colors2 = Arrays.asList("red", "blue", "white", "orange"); //
        Observable<String> stringObservable = Observable.fromIterable(colors2); // 공급자
        stringObservable.subscribe( color -> System.out.println(color) ); // 인자가 Consumer니까 먹어버리는 거라서 리턴이 없는 것

        // Stream 클래스 방식
        System.out.println();
        System.out.println( "Stream 클래스 방식" );
        List<String> colors3 = Arrays.asList("red", "blue", "white", "orange"); // DT는 동일하나 매핑을 List로 함
        Stream<String> streams = colors3.stream(); // 중간 연산
        streams.forEach( stream -> System.out.println(stream) ); // 최종 연산 forEach

        // 고전 방식
        System.out.println();
        System.out.println( "고전 방식" );
        List<String> colors4 = Arrays.asList("red", "blue", "white", "orange"); // DT는 동일하나 매핑을 List로 함
        for( String color : colors4 ){
            System.out.println( color );
        }

    }
}
