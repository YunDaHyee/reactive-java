package org.example.rxjava;

import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.schedulers.Schedulers;

import java.util.concurrent.ThreadLocalRandom;

public class ConcurrencyDemo02 {
    public static void main(String[] args) {
        Observable<String> source1 =
                Observable.just("Alpha", "Beta", "Gamma")
                        .subscribeOn(Schedulers.computation())
                        .map(s -> intenseCalculation((s)));

        Observable<Integer> source2 =
                Observable.range(1, 3)
                        .subscribeOn(Schedulers.computation())
                        .map(s -> intenseCalculation((s))); //데이터 하나하나가 emit되는 시간을 기다려서 랜덤한 시간동안 wait함.

        Observable.zip(source1, source2, (s, i) -> s + "-" + i) // 각각의 스레드에서 돌더라도 각 아이템에 대해 짝이 되면 바로 emit함
                .subscribe(System.out::println);

        sleep(20000);
    }

    public static <T> T intenseCalculation(T value) {
        sleep(ThreadLocalRandom.current().nextInt(3000));
        return value;
    }

    private static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
