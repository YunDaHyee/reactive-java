package org.example.rxjava;

import io.reactivex.rxjava3.core.Observable;

import java.util.concurrent.TimeUnit;

public class MergeDemo04 {
    public static void main(String[] args) {
        //emit every second
        Observable<String> src1 = Observable.interval(1, TimeUnit.SECONDS)
                .take(2) // 걍 2개만.. 왜냐면 src1가 무한 observer이라서 끝나지 않으니까 걍 2개로 제한한 거임.
                .map(l -> l + 1) // emit elapsed seconds
                .map(l -> "Source1: " + l + " seconds");

        //emit every 300 milliseconds
        Observable<String> src2 =
                Observable.interval(300, TimeUnit.MILLISECONDS)
                        .map(l -> (l + 1) * 300) // emit elapsed milliseconds
                        .map(l -> "Source2: " + l + " milliseconds");

        //merge and subscribe
        Observable
                .merge(src1, src2)
                .subscribe(System.out::println);

        // cf) concat and subscribe
       /*
       Observable
                .concat(src1, src2) // 소스1이 다 끝나고 소스2가 합쳐지는 것.
                .subscribe(System.out::println);
        */

        //keep alive for 3 seconds
        sleep(3000); // 3초를 살려놔야 그전에 데이터가 다 emit 되는 것.
    }

    private static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
