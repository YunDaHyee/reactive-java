package org.example.rxjava;

import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.schedulers.Schedulers;

import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

public class ConcurrencyDemo05 {
    public static void main(String[] args) {
        Observable
                .interval(1, TimeUnit.SECONDS)
                //.subscribeOn(Schedulers.newThread()) // 완전히 새로운 스레드를 만들어서 돌리는 건데 생성햇어도 이미 interval 자체가 Computation 쓰레드에서 도는거라서 똑같이 Computation 쓰레드를 그대로 씀.
                .subscribe(i ->
                        System.out.println("Received " + i +" on thread " + Thread.currentThread().getName())
                )
        ;
        // subSCribeOn가 잇을 경우의 결과값
        /*
            Received 0 on thread RxComputationThreadPool-1
            Received 1 on thread RxComputationThreadPool-1
            Received 2 on thread RxComputationThreadPool-1
            Received 3 on thread RxComputationThreadPool-1
            Received 4 on thread RxComputationThreadPool-1
         */

        Observable
                .interval( 1, TimeUnit.SECONDS, Schedulers.newThread() ) // ComputationThread가 아닌 새로운 스레드로 지정하려면 세 번째 인자에 새로운 걸로 지정.
                .subscribe(i ->
                        System.out.println("Ex 2=> Received " + i + " on thread " + Thread.currentThread().getName())
                )
        ;

        // subscribeOn은 하나만 적용됨. 여러개 있어도 첫 번째에 오는 subscribeOn이 반영된다.
        Observable.just("Alpha", "Beta", "Gamma", "Delta", "Epsilon")
                .subscribeOn(Schedulers.computation())
                .filter(s -> s.length() == 5)
                .subscribeOn(Schedulers.io())
                .subscribe(i ->
                        System.out.println("Ex 3=>Received " + i + " on thread " + Thread.currentThread().getName())
                )
        ;

        sleep(5000);
    }

    private static void sleep(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
