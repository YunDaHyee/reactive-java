package org.example.rxjava;

import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.schedulers.Schedulers;

import java.util.concurrent.ThreadLocalRandom;

public class ConcurrencyDemo03 {
    public static void main(String[] args) {
        Observable<Integer> lengths =
                    Observable
                        .just("Alpha", "Beta", "Gamma", "Delta", "Epsilon") // 메모리에 미리 올려놓음.
                        .subscribeOn(Schedulers.computation()) // 별도의 쓰레드로 돌겠다고 하는 것. 이게 없으면 같은 쓰레드인 메인쓰레드에서 구독자1,2가 같이 돔.
                        .map(d -> intenseCalculation(d) )
                        .map(String::length)
        ;

        lengths.subscribe(i ->
                System.out.println("Received " + i +" on thread " + Thread.currentThread().getName())
        ); // lazy excution. 쓰레드 실행 1. 이때 Observable이 만들어진 것.
        lengths.subscribe(i ->
                System.out.println("Received " + i +" on thread " + Thread.currentThread().getName())
        ); // 쓰레드 실행 2
        sleep(10000);
    }

    public static <T> T intenseCalculation(T value) {
        sleep(ThreadLocalRandom.current().nextInt(3000));
        return value;
    }

    private static void sleep(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
