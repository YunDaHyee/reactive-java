package org.example.reactor;

import org.reactivestreams.Subscription;
import reactor.core.CoreSubscriber;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class ReactorDemop01 {
    public static void main(String[] args) {
        // 1. publisher 생성. Spring에서는 Flux/Mono
        // Observable, Flowable의 역할.. 단일화
        Flux
            .just( "red", "blue", "orange" ) // 반환형 - Flux<String>, 데이터 3개
            .filter( d->d.length()>=3 ) // 반환형 - Flux<String>, 데이터 2개
            .map( d->d.toUpperCase() ) // 반환형 - Flux<String>, 데이터 2개, 모양이 다름
            .subscribe( d -> System.out.println(d) ); // CoreSubscriber 타입을 인자로 필요로 함. 자체적으로 구현된 Subscriber 가 있음. 그래서 따로 Subscriber를 만들 필욘 없다.

        // Single, Maybe, Complete 합쳐져있음.. 단일화
        Mono.just( "read" )
            .subscribe();
    }
}

class MySubscriber implements CoreSubscriber{

    @Override
    public void onSubscribe(Subscription subscription) { // Observerble이 아닌 Flowverble을 따라감.

    }

    @Override
    public void onNext(Object o) {

    }

    @Override
    public void onError(Throwable throwable) {

    }

    @Override
    public void onComplete() {

    }
}