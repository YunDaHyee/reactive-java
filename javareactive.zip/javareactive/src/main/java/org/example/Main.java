package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        int a = MyInterface.MY_INT;
        MyInterface.myFunction3(); // static 메서드를 바로 사용 가능.

        /* Functional Interface는 람다식으로 바꿀 수 있다.
            쥔공인 추상메서드를 람다식으로 변환하기 위한 방법
                1. 인터페이스를 구현해야 한다.
                2. 그 안에서 오버라이딩한 함수를 람다식으로 바꾼다.(키워드 제거, 함수명 제거, 중괄호 제거)
         */
        MyInterface mi = () -> System.out.println("Hello Lambda"); // 리턴이 없어도 한줄로만 코드되어 있으면 return 생략 가능함.
    }
}

// 1.
class ForLambda implements MyInterface{
    @Override
    public void myFunction() {
        System.out.println("Hello Lambda");
    }
}

@FunctionalInterface // 이걸 붙였다는 건 람다식으로 바꿀 수 있다는 것.
interface MyInterface{
    int MY_INT = 3; // 인터페이스라서 public final static임. 그래서 생략 가능. 그래서 인터페이스에서 정의되는 건 상수임.
    void myFunction(); // 인터페이스라서 public abstract는 기본임. 그래서 생략 가능. 추상메서드가 하나만 있으니까 이 인터페이스를 함수형인터페이스로 선언할 수 있음! 어노테이션! 글고 얘를 람다식으로 바꿀 수 있는거야!
    // void myFunction111(); // 추상메서드 두개가 있어도 어노테이션에서 에러가 남.
    default void myFunction2(){
        myPrivate();
        System.out.println("Hello"); // 이게 가능하려면 java8에서부터 가능한 키워드인 default 붙여주면 됨
    }

    static int myFunction3(){
        return 3;
    }

    // java9부터 private 메서드 지원.
    private void myPrivate(){
        System.out.println("Hello");
    }
}